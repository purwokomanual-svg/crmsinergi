/* =========================================================
   KONFIGURASI SUPABASE
   1. Salin file ini menjadi "config.js" (di folder yang sama)
   2. Isi SUPABASE_URL dan SUPABASE_ANON_KEY dengan nilai dari:
      Supabase Dashboard > Project Settings > API
   3. "anon key" AMAN untuk ditaruh di kode sisi klien —
      keamanan data diatur lewat Row Level Security (RLS)
      yang sudah didefinisikan di supabase/schema.sql.
      JANGAN PERNAH menaruh "service_role key" di sini.
   ========================================================= */

const SUPABASE_URL = 'https://xxxxxxxxxxxx.supabase.co';
const SUPABASE_ANON_KEY = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';

const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
